The GrizmoRetry folder contains a NetBeans project that can be imported
into NetBeans. This allows for review of Java class files used in
Stage 4.

To import it into NetBeans, ensure the latest version of NetBeans is
installed on your machine. Launch NetBeans, click File --> Import Project
--> From Zip...
Then locate the zipped GrizmoRetry folder and import it.